/*
Praktikum Pemrograman WEb
29 April 2019
Ifta Marlienna R, M0517024
*/

<hmtl>
<body>

<p>PEMWEB KELAS B</p>
<p>informatiks 11 maret</p>

//perbedaan include dan require adalah jika file tidak ditemukan program akan tetap dijalankan, kalau require program tidak akan dijalankan

<!--
<?php
include 'footer.php'
?>

<p>saya berada di kelas <?php echo $kelas[1]; ?></p>
-->

<!--/open file-->
<!--<?php
$baca = fopen("apa.json") or die ("gagal");
echo fread($baca, filesize("apa.json"));
fclose($baca);
?>-->


<!--read single line-->
<!--
<?php
$baca = fopen("apa.json") or die ("gagal");
echo fgets($baca);
fclose($baca);
?>
-->


<!--read single character-->
<!--
<?php
$baca = fopen("apa.json") or die ("gagal");
echo fgetc($baca);
fclose($baca);
?>
-->


<!--php write to file-->
<!--asumsikan sudah buat file baru-->
<!--
<?php
$baca = fopen("apa.json") or die ("gagal");
$write = "kelas kelas sss\n";
fwrite($baca, $write);
fclose($baca);
?>
-->

<!--file upload-->
<!--
<?php
$target_dir = "./uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
//untuk mengatur limit ukuran
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
//untuk mengatru limit type file
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
//untuk mengatur jika file sudah adda
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}

?>
-->

<!-- MYSQLi OOP 
<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "mydb"; 

// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Create database
$sql = "CREATE DATABASE myDB";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

// sql to create table
$sql = "CREATE TABLE MyGuests (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP
)";
if ($conn->query($sql) === TRUE) {
    echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}


//untuk insert multiple query
$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";
$sql .= "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close(); //menutup koneksi
?>

//untuk buat direktori pakai mkdir, cari di dikoding 
-->


</body>
</html>